// -----------------------------------------------------------------------------------------------//
//                                                                                                //
//                                    C L A S S E S                                               //
//                                                                                                //
// -----------------------------------------------------------------------------------------------//


function Courses_Classes_Display()
{
 var course   = Core_State_Get("courses", "selected-course", {});
 var display  = Core_State_Get("courses", "course-display"); 
 var locale   = UI_Language_Current(true);
 
 var classes  = course["classes"] || [];
 
 var prealloc = UI_Element_Find(display, "course-classes-preallocate");
 var rollout  = UI_Element_Find(display, "course-classes-rollout");
 var rollback = UI_Element_Find(display, "course-classes-rollback");
 
 
 // DETERMINE IF COURSE WAS ROLLED OUT
 var rolledout = Courses_Course_Rolledout(course);
 
 if(rolledout)
 {
  prealloc.style.display = "none";
  rollout.style.display  = "none";
  
  rollback.style.display = "flex";
  rollback.onclick       = Courses_Classes_Rollback;  
 }
 else
 {
  prealloc.style.display  = "flex";
  rollback.style.display  = "none";
  
  rollout.style.display   = "flex";
  rollout.onclick         = Courses_Classes_Rollout;  
 }
 
 var box       = UI_Element_Find(display, "course-classes");
 box.innerHTML = "";
 
 var lesson_duration = course["lesson_duration"];
 var lessons_day     = parseFloat(Core_Config(["course-lesson-durations", lesson_duration, "lessons-day"]));
 
 var n = 1;
 for(var item of classes)
 {
  var data = {};
  Object.assign(data, item);
 
  data["n"]     = String(Math.round(n / lessons_day)).padStart(3, "0")
  data["date"]  = Date_Format(data["date"], locale, "date-short-weekday"); 
  data["time"]  = Time_From_Minutes(data["time"]);
  
  if(!data["class"]) data["class"] = "";
  
  var element = UI_Element_Create("courses/course-classes-item", data);
  
  if(data["class"] != "")
  {
   var icon = UI_Element_Find(element, "view");
   icon.style.display = "flex";
   Document_Element_SetData(icon, "class", data["class"]);
   icon.onclick       = Courses_Classes_View;
  }
 
  box.appendChild(element)
  
  n++;
 }
}



async function Courses_Classes_View(event)
{
 var element = event.currentTarget;
 var id      = Document_Element_GetData(element, "class");

 await Class_Display(id);
}






async function Courses_Classes_Preallocate()
{
 var course  = Core_State_Get("courses", "selected-course", {});
 
 // 0. COMPLETENESS CHECK
 for(var field of ["program", "level", "lesson_duration", "schedule"])
 {
  if(!course[field] || (Array.isArray(course[field]) && course[field].length == 0))
  {
   var picture = Resources_URL("images/cover-deny.png");
   var title   = UI_Language_String("courses/popups", "allocate cant title"); 
   var content = UI_Language_String("courses/popups", "allocate missing " + field);
  
   await UI_Popup_Alert(title, content, picture);
   
   Courses_Course_HighlightMissing("allocate", field);
  
   return;
  }
 }

 
 var classes = [];
 var skipped = [];
 var count   = 0;
 
 // 1. GET LESSONS FROM PROGRAM/LEVEL COMBO
 var program  = course["program"] || "";
 var level    = course["level"]   || "";
 
 var lessons  = Core_Config(["programs", program, level], "").split(",");
 
 
 // 2. GET GLOBAL TIME-OFF AND COURSE'S CENTER TIME-OFF, COMBINED
 var center         = course["center_id"];
 var timeoff_center = await Timeoff_Read(center, "timeoff");
 var timeoff_global = await Timeoff_Read("global", "timeoff");

 // 3. SCAN DATES
 var lesson_duration = course["lesson_duration"];
 var lessons_day     = parseFloat(Core_Config(["course-lesson-durations", lesson_duration, "lessons-day"]));
 var lesson_time     = parseFloat(Core_Config(["course-lesson-durations", lesson_duration, "lesson-time"]));
 var lesson_content  = parseFloat(Core_Config(["course-lesson-durations", lesson_duration, "lesson-content"]));
 var date            = course["date_start"];
 var done            = false;
 var lesson_index    = 0;
 
 while(!done)
 {
  // CHECK IF THIS DATE'S WEEKDAY MATCHES COURSE SCHEDULE WEEKDAYS
  var weekday = Date_Weekday_Get(date);
  for(var item of course["schedule"] || [])
  {
   // IF THIS DAY MATCHES A COURSE SCHEDULE'S WEEKDAY...
   if(item["day"] == weekday)
   {
	// CHECK IF THE DATE FALLS ON A TIME-OFF SLOT
	var date_from = Date_Portion(date, "date-only") + Time_From_Minutes(item["time"], "");
	var date_to   = Date_Portion(Date_Add_Minutes(date_from, lesson_time), "no-seconds");
	var available = !Timeoff_Check(date_from, date_to, timeoff_center) && !Timeoff_Check(date_from, date_to, timeoff_global);

	// IF ALL CHECKS, LET'S CREATE LESSONS ACCORDING TO THE DURATION BREAKDOWN
	if(available)
	{
	 // INSERT N LESSONS PER DAY
     for(var n = 0; n < lessons_day; n++)
	 {	  
	  // LESSON INDEX DEPENDS ON LESSONS PER DAY
	  var lesson         = {};

	  lesson["date"]     = date;
 	  lesson["time"]     = Time_To_Minutes(Date_Portion(date_from, "time-only")) + Math.floor(lesson_time * n);
	  lesson["duration"] = lesson_time;
	  lesson["lesson"]   = lessons[Math.trunc(lesson_index)];
	 
	  classes.push(lesson);
	  lesson_index = lesson_index + lesson_content; 
	  
	  if(!done) done = (lesson_index >= (lessons.length - 1));
	  if(done) break;
	 }
	}
	else
    {
     skipped.push({date, time:time_from});
	}
   }
   
  }
  
  // MOVE ON
  date = Date_Portion(Date_Add_Days(date, 1), "date-only");
 }

 
 var last    = classes[classes.length - 1];
 var end     = last["date"];
 
 
 // UPDATE END DATE
 var element        = UI_Element_Find("course-date_end");
 element.value      = Date_To_Input(end);
 await Core_Api("Courses_Update_Field", {id:course["id"], field:"date_end", value:end, json:false});
 
 // UPDATE CLASSES
 await Core_Api("Courses_Update_Field", {id:course["id"], field:"classes", value:classes, json:true});
   
 // RELOAD
 Courses_Course_Display(course["id"]);
}






async function Courses_Classes_Rollout()
{
 var course = Core_State_Get("courses", "selected-course", {});
 
 
 // 0. COMPLETENESS CHECK
 for(var field of ["center_id", "classes"])
 {
  if(!Safe_Validate(course[field]))
  {
   var picture = Resources_URL("images/cover-deny.png");
   var title   = UI_Language_String("courses/popups", "rollout cant title"); 
   var content = UI_Language_String("courses/popups", "rollout missing " + field);
  
   await UI_Popup_Alert(title, content, picture);
   
   Courses_Course_HighlightMissing("rollout", field);
  
   return;
  }
 }
 
 
 // 1. STAFF CHECK
 var staff = course["staff"] || {};
 // 1a. AT LEAST EITHER A NATIVE OR LOCAL TEACHER
 if(!staff["teacher_id"] && !staff["local_id"])
 {
  // WARN
  var picture = Resources_URL("images/cover-deny.png");
  var title   = UI_Language_String("courses/popups", "rollout cant title"); 
  var content = UI_Language_String("courses/popups", "rollout missing teacher");

  await UI_Popup_Alert(title, content, picture); 
  
  Courses_Course_HighlightMissing("rollout", "teacher");

  // RETURN	
  return;
 }
 
 
 // 1b. AT LEAST 1 TA
 var found = false;
 for(var id in staff)
 {
  if(id.startsWith("ta"))
  {
   found = true;
   break;
  }
 }
 if(!found)
 {
  // WARN
  var picture = Resources_URL("images/cover-deny.png");
  var title   = UI_Language_String("courses/popups", "rollout cant title"); 
  var content = UI_Language_String("courses/popups", "rollout missing ta");
  
  await UI_Popup_Alert(title, content, picture);
  
  Courses_Course_HighlightMissing("rollout", "ta");
 
  // RETURN	
  return;
 }
 
 
 // 1c. ALL THE REQUIRED STAFF ACCORDING TO CONFIG
 var options = Core_Data_Page("courses/course-config");
 var config  = course["config"] || [];
 for(var item of config)
 {
  var required = Safe_Get(options, [item, "required"], "").split(",");
  for(var role of required)
  if(role != "")
  {
   if(!staff[role])
   {
	// WARN
    var picture = Resources_URL("images/cover-deny.png");
    var title   = UI_Language_String("courses/popups", "rollout cant title"); 
    var content = UI_Language_String("courses/popups", "rollout missing staff");
	
	await UI_Popup_Alert(title, content, picture);
	
	Courses_Course_HighlightMissing("rollout", "staff");
 
    // RETURN	
    return;
   }
  }
 } 


 // ROLL OUT
 
 // 1. CONFIRM
 var picture  = Resources_URL("images/cover-alert.jpg");
 var title    = UI_Language_String("courses/popups", "rollout confirm title"); 
 var content  = UI_Language_String("courses/popups", "rollout confirm text"); 
 
 var confirm  = await UI_Popup_Confirm(title, content, picture);
 if(!confirm) return;
 
 // 2. ROLL OUT
 var result   = await Core_Api("Courses_Rollout", {id:course["id"]});
 switch(result)
 {
  case "done":
	// ROLLOUT SUCCESSFUL
  break;
  
  default:
	// ERROR
	console.log(result);
  break;
 }
 
 // RELOAD
 Courses_Course_Display(course["id"]);
}





async function Courses_Classes_Rollback()
{
 var course = Core_State_Get("courses", "selected-course", {});
 
 
 // 1. CONFIRM
 var code     = course["id"].padStart(6, "0");
 
 var picture  = Resources_URL("images/cover-alert.jpg");
 var title    = UI_Language_String("courses/popups", "rollback confirm title"); 
 var content  = UI_Language_String("courses/popups", "rollback confirm text", {code});
 
 var confirm  = await UI_Popup_Code(title, content, picture, code);
 if(!confirm) return;
 
 
 // 2. CALL ROLLBACK SERVICE
 await Core_Api("Courses_Rollback", {id:course["id"]});
 
 
 // 3. RELOAD
 Courses_Course_Display(course["id"]);
}




async function People_Available(center, roles, dates)
{
 // NOTE THAT DATES MUST BE PACKAGED AS [date:{time_from, time_to}, date:{time_from, time_to}]  
 var centers = Centers_Related(center, true);
 
 var users   = await Core_Api("Users_Teaching_Avail", {centers, roles, dates});
 
 return users;
}