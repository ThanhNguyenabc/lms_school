// -----------------------------------------------------------------------------------------------//
//                                                                                                //
//                                       C O N F I G                                              //
//                                                                                                //
// -----------------------------------------------------------------------------------------------//


function Courses_Config_Display()
{
 var course    = Core_State_Get("courses", "selected-course", {});
 var display   = Core_State_Get("courses", "course-display");
  
 var box       = UI_Element_Find(display, "course-config");
 box.innerHTML = "";
 
 var config    = course["config"] || [];
 var items     = Core_Data_Page("courses/course-config");
 for(var id in items)
 {  
  var option      = new Option();
  
  option.text     = UI_Language_Object(items[id]);
  option.value    = id;
  option.selected = config.includes(id);
  
  option.onclick  = Courses_Config_Change;
  
  box.appendChild(option);
 }
}



async function Courses_Config_Change(event)
{
 await Courses_Config_Update();
 Courses_Config_Display();
}



async function Courses_Config_Update()
{ 
 var course  = Core_State_Get("courses", "selected-course", {});
 var display = Core_State_Get("courses", "course-display");
 var select  = UI_Element_Find(display, "course-config");
 var config  = Document_Select_SelectedValues(select);
 var staff   = Safe_Get(course, "staff", {});
  
 
 // SPECIAL CASE : IF CONFIGURATION NOW CONTAINS NEITHER "native local" NOR "local native" BUT A local_id IS SPECIFIED IN THE STAFF SECTION,
 // WE MUST UNSET THAT STAFF
 if(staff["local_id"] && !config.includes("local native") && !config.includes("native local"))
 {
  // ALERT
  var picture = Resources_URL("images/cover-alert.jpg");
  var title   = UI_Language_String("courses/popups", "config nolocalteacher title"); 
  var text    = UI_Language_String("courses/popups", "config nolocalteacher text");
   
  await UI_Popup_Alert(title, text, picture);
   
  // UPDATE
  var user_id = staff["local_id"]["id"];   
  await Courses_Staff_Unset(false, user_id);
 }


 // UPDATE
 course["config"] = config;
 
 await Core_Api("Courses_Update_Field", {id:course["id"], field:"config", value:config, json:true});
}