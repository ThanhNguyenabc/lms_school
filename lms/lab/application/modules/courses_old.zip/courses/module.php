<?PHP

function Courses_Load()
{
}



function Courses_Read($id, $fields = "*", $info = false)
{
 // QUERY 
 $db = Core_Database_Open();
 
 $query = "SELECT $fields FROM courses WHERE id = $id";
 $data  = SQL_Query($query, $db);
 
 SQL_Close($db);
 
 $course = $data[0];
 
 // DECODE JSON FIELDS
 $decode = ["schedule", "staff", "students", "classes", "config"];
 Array_Fields_JSONParse($course, $decode);
 foreach($decode as $field) if(!$course[$field]) $course[$field] = [];
 
 // LOAD STUDENTS & STAFF INFO?
 foreach(["students", "staff"] as $section)
 {
  
  if($info && ($info["staff"] || $info["all"]))
  { 
   $ids   = array_values($course[$section]); 
   $users = Users_Read($ids);
  
   $keys = array_keys($course[$section]);
   foreach($keys as $key)
   {
    $id         = $course[$section][$key];
    
    $user       = [];
    $user["id"] = $key;
	$userinfo   = $users[$id] ?? [];
    $user       = array_merge($user, $userinfo); 
	 
    $course[$section][$key] = $user;
   }
  }
  
 }
 
 
 
 
 return $course;
}




function Courses_Update_Field($id, $field, $value, $json = false)
{
 $db = Core_Database_Open();
 
 if($json) $value = json_encode($value);
 $value  = SQL_Format($value, $db);

 $query = "UPDATE courses SET $field = $value WHERE id = $id";
 $data  = SQL_Query($query, $db);
 
 SQL_Close($db);
}



function Courses_Ongoing($centers, $fields = "id, name")
{
 $date    = Date_Format_As(Date_Now(), "date-only");
 
 $db      = Core_Database_Open();
 
 $centers = SQL_Format_IN($centers, $db);
 
 $query   = "SELECT $fields FROM courses WHERE center_id IN ($centers) AND (date_end >= $date) ORDER BY date_start";
 $data    = SQL_Query($query, $db);
 
 SQL_Close($db);
 
 return $data;
}



function Courses_List($status = false, $centers = false, $program = false, $level = false, $date_from = false, $date_to = false, $order = "date_start")
{
 $conditions = [];
  
  
 // STATUS
 if($status)
 {
  array_push($conditions, "status = '$status'");
 }
  
  
 // CENTERS
 if($centers)
 {
  foreach($centers as &$center) $center = "'$center'";
  
  $centers = implode(",", $centers);
  
  array_push($conditions, "center_id IN ($centers)");
 }
 
 
 // PROGRAM
 if($program)
 {    
  array_push($conditions, "program = '$program'");
 }
 
 
 // LEVEL
 if($level)
 {    
  array_push($conditions, "level = '$level'");
 }
 
 
 // DATE FROM
 if($date_from)
 {   
  $date_from = Date_Format_As($date_from, "date-only");
  
  array_push($conditions, "date_start >= $date_from");
 }
 
 
 // DATE TO
 if($date_to)
 {   
  $date_to = Date_Format_As($date_to, "date-only");
  
  array_push($conditions, "date_start <= $date_to");
 }
 
 $conditions = implode(" AND ", $conditions);
 
 
 // QUERY 
 $db = Core_Database_Open();
 
 $query = "SELECT * FROM courses WHERE $conditions ORDER BY $order";
 $data  = SQL_Query($query, $db);
 
 SQL_Close($db);
 
 // DECODE JSON FIELDS
 Array_Items_JSONParse($data, ["schedule", "staff", "students", "classes", "config"]);
 
 
 // CALCULATE SEATS LEFT
 foreach($data as &$item) 
 {
  $seats = [];
  $seats["taken"] = count($item["students"] ?? []);
  $seats["total"] = $item["seats"] ?? 0;
  
  unset($item["students"]);
  $item["seats"] = $seats;
 }
 
 
 // CALCULATE CLASSES LEFT
 $now = Date_Format_As(Date_Now(), "date-only");
 foreach($data as &$item) 
 {
  $all   = $item["classes"] ?? [];
  $taken = 0;
  
  foreach($all as $class)
  {
   $date = $class["date"];
   
   if($date < $now)
   {
	$taken = $taken + 1;
   }
   else 
   {
	break;
   }
  }
  
  $classes          = [];
  $classes["taken"] = $taken;
  $classes["total"] = count($all);
  
  $item["classes"]  = $classes;
 }
 
 
 
 return $data;
}



function Courses_New($data)
{
 $db = Core_Database_Open();
 
 $insert = SQL_Fields_Insert($data, $db);
 $query  = "INSERT INTO courses $insert";
 $id     = SQL_Query($query, $db);
 
 SQL_Close($db);
 
 return $id;
}




function Courses_Rollout($id)
{
 // 1. READ COURSE
 $course = Courses_Read($id);
 
 
 // 2a. PACKAGE CLASSES IN A FORMAT THAT CAN BE USED BY THE BATCH CLASSES CREATION SERVICE
 $data    = [];
 $classes = $course["classes"] ?: [];
 foreach($classes as $class)
 {
  $slot = [];
  
  $slot["date_start"] = Date_Add_Minutes($class["date"], $class["time"]);
  $slot["date_end"]   = Date_Add_Minutes($slot["date_start"], $class["duration"]); 
  $slot["duration"]   = $class["duration"];
  $slot["lesson_id"]  = $class["lesson"];
  
  $slot["teacher_id"] = $class["teacher_id"];
  $slot["ta1_id"]     = $class["ta1_id"];
  $slot["ta2_id"]     = $class["ta2_id"];
  $slot["ta3_id"]     = $class["ta3_id"];
  
  array_push($data, $slot);
 }
 
 // 2b. PACKAGE FIXED DATA
 $fixed                = [];
 $fixed["course_id"]   = $course["id"];
 $fixed["center_id"]   = $course["center_id"];
 $fixed["seats_total"] = $course["seats"];
 
  
 // 3. FIND AN AVAILABLE ROOM
 
 // IF CONFIGURATION SETS THIS COURSE AS "ONLINE", ROOM WILL BE NULL AND THE ONLINE FLAG MUST BE SET
 if(in_array("online", $course["config"]))
 {
  $fixed["classroom_id"] = NULL;
  $fixed["online"] = 1;
 }
 else
 // OTHERWISE WE NEED TO FIND A ROOM THAT IS AVAILABLE THROUGHOUT THE WHOLE COURSE CALENDAR
 {
  $rooms = Center_Rooms_Available($course["center_id"], $data);
 
  // NO AVAILABLE ROOMS = FAIL TO ROLL OUT
  if(count($rooms) == 0)
  {
   return "no rooms";
  }
 
  // GET FIRST AVAILABLE ROOM AND USE IT
  $room                  = $rooms[0];
  $fixed["classroom_id"] = $room;
 }
 
 
 // 4. CREATE A BATCH OF CLASSES ACCORDING TO DATA, GET IDS FOR EACH ONE
 $students = $course["students"] ?: [];
 
 $ids     = Classes_Create_Batch($data, $fixed, $students);
 
 $db      = Core_Database_Open();
 
 $rows    = SQL_Query("SELECT classes FROM courses WHERE id = $id", $db); 
 $classes = json_decode($rows[0]["classes"], true);
 
 for($i = 0; $i<count($classes); $i++)
 {
  $classes[$i]["class"] = $ids[$i];
 }
 
 $classes = json_encode($classes);
 $classes = SQL_Format($classes, $db);
 SQL_Query("UPDATE courses SET classes = $classes WHERE id = $id", $db);
 
 SQL_Close($db);
 
 return "done";
}




function Courses_Rollback($id)
{  
 $db = Core_Database_Open();
 
 
 // COLLECT CLASSES IDS FROM TOMORROW ONWARD
 $tomorrow = Date_Format_As(Date_Now(), "date-only") . "2359";
 $tomorrow = SQL_Format($tomorrow, $db);
 
 $classes  = SQL_Query("SELECT id FROM classes WHERE course_id = $id AND date_start >= $tomorrow", $db);
 
 $ids      = array_column($classes, "id");
 $ids      = SQL_Format_IN($ids, $db);
 
 if(!$ids) return;
  
 // REMOVE CLASSES AND SEATS
 SQL_Query("DELETE FROM classes WHERE id IN ($ids)", $db); 
 SQL_Query("DELETE FROM classes_seats WHERE class_id IN ($ids)", $db); 
 
 
 // UPDATE COURSE (LESSONS OBJECT AND STATUS)
 $courses = SQL_Query("SELECT classes FROM courses WHERE id = $id", $db);
 $course  = $courses[0];
 $classes = $course["classes"];
 $classes = json_decode($classes, true);
 
 $tomorrow = Date_Format_As(Date_Now(), "date-only");
 foreach($classes as &$class)
 {
  if($class["date"] >= $tomorrow)
  {
   unset($class["class"]);
  }
 }
 
 $classes = json_encode($classes);
 $classes = SQL_Format($classes, $db);
 SQL_Query("UPDATE courses SET classes = $classes' WHERE id = $id", $db); 
 
 SQL_Close($db);
}



function Courses_UpdateSeats($id)
{
 $db = Core_Database_Open();
  
 // GET STUDENTS ASSIGNED TO THE COURSE
 $rows     = SQL_Query("SELECT students FROM courses WHERE id = $id", $db);
 $students = $rows[0]["students"];
 $students = json_decode($students, true);
 
 // GET ALL CLASSES BOUND TO THIS COURSE, AFTER CURRENT DATE
 $today   = Date_Format_As(Date_Now(), "date-only") . "2359";
 $classes = SQL_Query("SELECT id FROM classes WHERE course_id = $id AND date_start > $today", $db);

 // FOR EACH CLASS, CREATE A SEAT FOR EACH STUDENT
 $db->beginTransaction();
 foreach($classes as $class)
 {
  $class_id = $class["id"];
  
  foreach($students as $student_id)
  {  
   SQL_Query("INSERT INTO classes_seats (class_id, student_id) VALUES($class_id, $student_id)", $db);
  }
 }
 
 $db->commit();
 
 
 SQL_Close($db);
}




function Courses_Students_Add($id, $student_id, $seats = false)
{
 $db = Core_Database_Open();
  
 // GET STUDENTS AND CLASSES
 $rows   = SQL_Query("SELECT students, classes FROM courses WHERE id = $id", $db);
 $course = $rows[0];
 
 $students = $course["students"];
 $students = json_decode($students, true);
 
 
 // CHECK COURSE SEATS LIMIT
 if($course["seats"])
 {
  if(count(array_keys($students)) >= $course["seats"])
  {
   SQL_Close($db);  
   return "no seats";
  }	  
 }	 
 
 
 // UPDATE STUDENTS OBJECT
 if(!in_array($student_id, $students)) array_push($students, $student_id);
 
 $students = json_encode($students);
 $students = SQL_Format($students, $db);
 SQL_Query("UPDATE courses SET students = $students WHERE id = $id", $db);
 
 
 // IF REQUESTED, CREATE SEATS FOR ALL CLASSES FROM TOMORROW ONWARD
 $classes = $course["classes"];
 $classes = json_decode($classes, true);
 $today   = Date_Format_As(Date_Now(), "date-only");
 
 $db->beginTransaction();
 foreach($classes as $class)
 {
  if($class["date"] > $today)
  {
   $class_id = $class["class"];
   SQL_Query("INSERT INTO classes_seats (class_id, student_id) VALUES($class_id, $student_id)", $db);
  }
 }
 $db->commit();
 
 SQL_Close($db);
}


function Courses_Students_Remove($id, $student_id, $seats = false)
{ 
 $db = Core_Database_Open();
  
 // GET STUDENTS AND CLASSES
 $rows   = SQL_Query("SELECT students, classes FROM courses WHERE id = $id", $db);
 $course = $rows[0];
 
 // UPDATE OBJECT
 $students = $course["students"];
 $students = json_decode($students, true);
 Array_Item_Delete($students, $student_id);
 
 $students = json_encode($students);
 $students = SQL_Format($students, $db);
 SQL_Query("UPDATE courses SET students = $students WHERE id = $id", $db);
 
 
 // REMOVE SEATS FOR ALL CLASSES FROM TOMORROW ONWARD
 $classes = $course["classes"];
 $classes = json_decode($classes, true);
 $today   = Date_Format_As(Date_Now(), "date-only");
 
 $db->beginTransaction();
 foreach($classes as $class)
 {
  if($class["date"] > $today)
  {
   $class_id = $class["class"];
   SQL_Query("DELETE FROM classes_seats WHERE class_id = $class_id AND student_id = $student_id", $db);
  }
 }
 $db->commit();
}




function Courses_Delete($id)
{
 // COLLECT STAFF IDS
 $course = Courses_Read($id, "staff");
 
 $staff  = $course["staff"] ?: [];
 $staff  = array_values($staff);
  
 // FREE UP PRELLOCATED TIMEOFF FOR STAFF, IF ANY
 $markers = [];
 $markers["course_id"] = $id;
 foreach($staff as $user_id)
 {
  Timeoff_RemoveBatch("users/" . $user_id . "/courses-prealloc", $markers);
 }
 
 
 // ROLLBACK ALLOCATED CLASSES, IF ANY
 Courses_Rollback($id);
 
 
 // DELETE COURSE FROM DATABASE
 $db = Core_Database_Open();
 
 $query  = "DELETE FROM courses WHERE id = $id";
 SQL_Query($query, $db);
 
 SQL_Close($db);
}




?>